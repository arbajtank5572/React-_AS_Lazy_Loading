import React, { Suspense, lazy } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

{
  //User_Side
}

const Home = lazy(() => import("./Website/Pages/Home"));
const About = lazy(() => import("./Website/Pages/About"));
const Products = lazy(() => import("./Website/Pages/Products"));
const Contact = lazy(() => import("./Website/Pages/Contact"));
const Blog = lazy(() => import("./Website/Pages/Blog"));
const PNF = lazy(() => import("./Website/Pages/PNF"));
const Sign_up = lazy(() => import("./Website/Pages/Sign_up"));
const User_Login = lazy(() => import("./Website/Pages/User_Login"));
const Profile = lazy(() => import("./Website/Pages/Profile"));
const Edit_Profile = lazy(() => import("./Website/Pages/Edit_Profile"));
const All_Products = lazy(() => import("./Website/Pages/All_Products"));
const Add_to_card = lazy(() => import("./Website/Pages/Add_to_card"));

{
  // admin_side
}

const Dashboard = lazy(() => import("./Admin/Pages/Dashboard"));
const Add_Categories = lazy(() => import("./Admin/Pages/Add_Categories"));
const Manage_Categories = lazy(() => import("./Admin/Pages/Manage_Categories"));
const Add_Product = lazy(() => import("./Admin/Pages/Add_Product"));
const Manage_Product = lazy(() => import("./Admin/Pages/Manage_Product"));
const Add_Blog = lazy(() => import("./Admin/Pages/Add_Blog"));
const Manage_Contacts = lazy(() => import("./Admin/Pages/Manage_Contacts"));
const Manage_User = lazy(() => import("./Admin/Pages/Manage_User"));
const Admin_Login = lazy(() => import("./Admin/Pages/Admin_Login"));
const Admin_Profile = lazy(() => import("./Admin/Pages/Admin_Profile"));
const Edit_Admin_Profile = lazy(() =>
  import("./Admin/Pages/Edit_Admin_Profile")
);

function App() {
  return (
    <div>
      <BrowserRouter>
        <Suspense
          fallback={
            <div
              className="d-flex justify-content-center"
              style={{ marginTop: "50vh" }}
            >
              <div className="spinner-border "></div>
            </div>
          }
        >
          <ToastContainer />

          <Routes>
            {
              // User_Side
            }
            <Route path="/" element={<Home />}></Route>
            <Route path="/about" element={<About />}></Route>
            <Route path="/products" element={<Products />}></Route>
            <Route path="/contact" element={<Contact />}></Route>
            <Route path="/blog" element={<Blog />}></Route>
            <Route path="*" element={<PNF />}></Route>
            <Route path="/sign_up" element={<Sign_up />}></Route>
            <Route path="/user_login" element={<User_Login />}></Route>
            <Route path="/profile" element={<Profile />}></Route>
            <Route path="/edit_profile/:id" element={<Edit_Profile />}></Route>
            <Route
              path="/all_products/:cate_id"
              element={<All_Products />}
            ></Route>
            <Route
              path="/add_to_card/:cate_id"
              element={<Add_to_card />}
            ></Route>
            
            {
              // Admin_Side
            }
            <Route path="/dashboard" element={<Dashboard />}></Route>
            <Route path="/add_category" element={<Add_Categories />}></Route>
            <Route
              path="/manage_category"
              element={<Manage_Categories />}
            ></Route>
            <Route path="/add_product" element={<Add_Product />}></Route>
            <Route path="/manage_product" element={<Manage_Product />}></Route>
            <Route path="/add_blog" element={<Add_Blog />}></Route>
            <Route path="/contacts" element={<Manage_Contacts />}></Route>
            <Route path="/manage_user" element={<Manage_User />}></Route>
            <Route path="/admin_login" element={<Admin_Login />}></Route>
            <Route path="/admin_profile" element={<Admin_Profile />}></Route>
            <Route
              path="/edit_admin_profile/:id"
              element={<Edit_Admin_Profile />}
            ></Route>
          </Routes>
        </Suspense>
      </BrowserRouter>
    </div>
  );
}

export default App;
