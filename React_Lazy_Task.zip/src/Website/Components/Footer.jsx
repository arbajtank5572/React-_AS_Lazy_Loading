import React from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";

function Footer() {
  return (
    <div>
      <footer class="site-footer">
        <div class="container">
          <div class="row">
            <div class="col-lg-3 col-10 me-auto mb-4">
              <h4 class="text-white mb-3">
                <Link to="/">Little</Link> Fashion
              </h4>
              <p class="copyright-text text-muted mt-lg-5 mb-4 mb-lg-0">
                Copyright © 2022 <strong>Little Fashion</strong>
              </p>
              <br />
              <p class="copyright-text">
                Designed by
                <Link to="#">Tooplate</Link>
              </p>
            </div>

            <div class="col-lg-5 col-8">
              <h5 class="text-white mb-3">Sitemap</h5>

              <ul class="footer-menu d-flex flex-wrap">
                <li class="footer-menu-item">
                  <a href="#" class="footer-menu-link">
                    Story
                  </a>
                </li>

                <li class="footer-menu-item">
                  <a href="#" class="footer-menu-link">
                    Products
                  </a>
                </li>

                <li class="footer-menu-item">
                  <a href="#" class="footer-menu-link">
                    Privacy policy
                  </a>
                </li>

                <li class="footer-menu-item">
                  <a href="#" class="footer-menu-link">
                    FAQs
                  </a>
                </li>

                <li class="footer-menu-item">
                  <a href="#" class="footer-menu-link">
                    Contact
                  </a>
                </li>
              </ul>
            </div>

            <div class="col-lg-3 col-4">
              <h5 class="text-white mb-3">Social</h5>

              <ul class="social-icon">
                <li>
                  <a href="#" class="social-icon-link bi-youtube"></a>
                </li>

                <li>
                  <a href="#" class="social-icon-link bi-whatsapp"></a>
                </li>

                <li>
                  <a href="#" class="social-icon-link bi-instagram"></a>
                </li>

                <li>
                  <a href="#" class="social-icon-link bi-skype"></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
      <Helmet>
        <script src="../website/js/jquery.min.js"></script>  
        <script src="../website/js/Headroom.js"></script>
        <script src="/website/js/jQuery.headroom.js"></script>
        <script src="/website/js/custom.js"></script>
        <script src="../website/js/bootstrap.bundle.min.js"></script>
      </Helmet>
    </div>
  );
}

export default Footer;
